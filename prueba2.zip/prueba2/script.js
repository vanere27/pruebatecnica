const correctAnswers = {
      1: 'a',
      2: 'b',
      3: 'b',
      4: 'b'
    };

    function checkAnswer(question, answer) {
      const feedbackEl = document.getElementById("feedback" + question);
      if (answer === correctAnswers[question]) {
        feedbackEl.textContent = "✅ ¡Correcto!";
        feedbackEl.style.color = "lightgreen";
      } else {
        feedbackEl.textContent = "❌ Incorrecto, intenta de nuevo.";
        feedbackEl.style.color = "red";
      }
    }